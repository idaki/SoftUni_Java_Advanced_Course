package PB04_Traffic_Lights;

public enum Signals {
    GREEN,
    RED,
    YELLOW;


}
