package PB01_Card_Suit_E;

public enum CardsSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
