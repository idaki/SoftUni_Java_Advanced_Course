package PB03_Players_and_Monsters.Hero.Wizard;

import PB03_Players_and_Monsters.Hero.Hero;

public class Wizard extends Hero {

    public Wizard(String username, int level) {
        super(username, level);
    }
}
