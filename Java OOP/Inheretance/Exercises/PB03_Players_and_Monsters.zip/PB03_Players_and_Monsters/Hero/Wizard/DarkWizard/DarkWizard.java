package PB03_Players_and_Monsters.Hero.Wizard.DarkWizard;

import PB03_Players_and_Monsters.Hero.Wizard.Wizard;

public class DarkWizard extends Wizard {

    public DarkWizard(String username, int level) {
        super(username, level);
    }
}
