package PB03_Players_and_Monsters.Hero.Wizard.DarkWizard.SoulMaster;

import PB03_Players_and_Monsters.Hero.Wizard.DarkWizard.DarkWizard;

public class SoulMaster extends DarkWizard {

    public SoulMaster(String username, int level) {
        super(username, level);
    }
}
