package PB03_Players_and_Monsters.Hero.Elf;

import PB03_Players_and_Monsters.Hero.Hero;

public class Elf extends Hero {

    public Elf(String username, int level) {
        super(username, level);
    }
}
