package PB03_Players_and_Monsters.Hero.Elf.MuseElf;

import PB03_Players_and_Monsters.Hero.Elf.Elf;

public class MuseElf extends Elf {

    public MuseElf(String username, int level) {
        super(username, level);
    }
}
