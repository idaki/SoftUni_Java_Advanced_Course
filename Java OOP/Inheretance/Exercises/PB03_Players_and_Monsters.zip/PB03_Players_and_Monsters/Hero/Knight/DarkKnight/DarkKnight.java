package PB03_Players_and_Monsters.Hero.Knight.DarkKnight;

import PB03_Players_and_Monsters.Hero.Knight.Knight;

public class DarkKnight extends Knight {

    public DarkKnight(String username, int level) {
        super(username, level);
    }
}
