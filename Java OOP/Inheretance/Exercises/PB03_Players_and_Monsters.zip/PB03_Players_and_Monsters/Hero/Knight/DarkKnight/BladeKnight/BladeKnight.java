package PB03_Players_and_Monsters.Hero.Knight.DarkKnight.BladeKnight;

import PB03_Players_and_Monsters.Hero.Knight.DarkKnight.DarkKnight;

public class BladeKnight extends DarkKnight {

    public BladeKnight(String username, int level) {
        super(username, level);
    }
}
