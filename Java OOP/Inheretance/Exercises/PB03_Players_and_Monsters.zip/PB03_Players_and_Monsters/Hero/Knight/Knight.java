package PB03_Players_and_Monsters.Hero.Knight;

import PB03_Players_and_Monsters.Hero.Hero;

public class Knight extends Hero {

    public Knight(String username, int level) {
        super(username, level);
    }
}
