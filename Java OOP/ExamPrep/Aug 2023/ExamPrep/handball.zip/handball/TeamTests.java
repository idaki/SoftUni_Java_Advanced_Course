package handball;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TeamTests {

    private HandballPlayer player1;
    private HandballPlayer player2;
    private Team team1;
    private Team team2;

    @Before
    public void setUp() {
        this.player1 = new HandballPlayer("Player1");
        this.player2 = new HandballPlayer("Player2");
        this.team1 = new Team("team1", 1);
        this.team2 = new Team("team2", 2);
    }

    @Test
    public void TestConstructorCreation() {
        Assert.assertEquals("team1", team1.getName());
        Assert.assertEquals(1, team1.getPosition());
    }

    @Test
    public void TestGetName() {
        Assert.assertEquals("team1", team1.getName());
    }

    @Test(expected = NullPointerException.class)
    public void testSetNamePositiveNegativeCaseWithNullName() {
        Team team = new Team(null, 2);
    }

    @Test(expected = NullPointerException.class)
    public void testSetNamePositiveNegativeCaseWithEmptyStringName() {
        Team team = new Team("", 3);
    }

    @Test
    public void testGetPosition() {
        Assert.assertEquals(1, this.team1.getPosition());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetPositionNegativeCase() {
        Team abc = new Team("ABC", -3);
    }

    @Test
    public void testGetCount() {
        this.team1.add(player1);
        Assert.assertEquals(1, team1.getCount());
    }

    @Test
    public void addPlayerPositive() {
        this.team2.add(player1);
        this.team2.add(player2);
        Assert.assertEquals(2,this.team2.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void addPlayerNegative() {
        this.team1.add(player1);
        this.team1.add(player2);

    }

    @Test
    public void testRemovePlayerPositive() {
        this.team2.add(player1);
        this.team2.add(player2);
        this.team2.remove("Player1");
        Assert.assertEquals(1, this.team2.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemovePlayerNegative() {
        this.team2.add(player1);
        this.team2.add(player2);
        this.team2.remove("unknown");
    }

    @Test
    public void getStatistics(){
        this.team2.add(player1);
        this.team2.add(player2);
        Assert.assertEquals("The player Player1, Player2 is in the team team2.",this.team2.getStatistics());
    }

@Test
    public void testPlayerForAnotherTeamPositiveCase(){
        team2.add(player1);
        team2.add(player1);
        team2.playerForAnotherTeam("Player1");
        Assert.assertFalse(player1.isActive());
}
    @Test(expected = IllegalArgumentException.class)
    public void testPlayerForAnotherTeamNegativeCase(){
        team2.add(player1);
        team2.add(player1);
        team2.playerForAnotherTeam("unknown");

    }


}
