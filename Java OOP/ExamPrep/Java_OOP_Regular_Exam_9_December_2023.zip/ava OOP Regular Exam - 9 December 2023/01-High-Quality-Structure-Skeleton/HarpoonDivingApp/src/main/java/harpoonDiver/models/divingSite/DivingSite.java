package harpoonDiver.models.divingSite;

import java.util.Collection;

public interface DivingSite {

    Collection<String> getSeaCreatures();

    String getName();
}
