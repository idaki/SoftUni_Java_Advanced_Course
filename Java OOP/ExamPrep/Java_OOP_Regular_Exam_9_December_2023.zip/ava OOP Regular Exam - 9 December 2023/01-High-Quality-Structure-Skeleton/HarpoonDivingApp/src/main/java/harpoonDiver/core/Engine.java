package harpoonDiver.core;

public interface Engine extends Runnable{

}
