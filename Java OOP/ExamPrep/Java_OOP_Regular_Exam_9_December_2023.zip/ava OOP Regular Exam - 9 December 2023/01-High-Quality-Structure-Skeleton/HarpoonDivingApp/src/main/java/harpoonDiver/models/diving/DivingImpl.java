package harpoonDiver.models.diving;

import harpoonDiver.models.diver.Diver;
import harpoonDiver.models.divingSite.DivingSite;
import harpoonDiver.models.seaCatch.BaseSeaCatch;
import harpoonDiver.models.seaCatch.SeaCatch;

import java.util.Collection;
import java.util.Collections;

public class DivingImpl implements Diving {
    @Override
    public void searching(DivingSite divingSite, Collection<Diver> divers) {

        for (Diver diver : divers) {

            while (diver.canDive() && !divingSite.getSeaCreatures().isEmpty()) {
                String seaCreature = divingSite.getSeaCreatures().iterator().next();
                diver.shoot();
                diver.getSeaCatch().getSeaCreatures().add(seaCreature);
                divingSite.getSeaCreatures().remove(seaCreature);

            }
        }
    }
}

