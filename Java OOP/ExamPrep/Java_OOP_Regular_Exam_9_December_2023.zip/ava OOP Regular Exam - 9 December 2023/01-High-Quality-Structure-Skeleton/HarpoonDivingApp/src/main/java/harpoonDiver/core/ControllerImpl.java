package harpoonDiver.core;

import harpoonDiver.common.Command;
import harpoonDiver.common.ConstantMessages;
import harpoonDiver.common.ExceptionMessages;
import harpoonDiver.models.diver.DeepWaterDiver;
import harpoonDiver.models.diver.Diver;
import harpoonDiver.models.diver.OpenWaterDiver;
import harpoonDiver.models.diver.WreckDiver;
import harpoonDiver.models.diving.Diving;
import harpoonDiver.models.diving.DivingImpl;
import harpoonDiver.models.divingSite.DivingSite;
import harpoonDiver.models.divingSite.DivingSiteImpl;
import harpoonDiver.repositories.DiverRepository;
import harpoonDiver.repositories.DivingSiteRepository;

import java.util.*;
import java.util.stream.Collectors;

import static harpoonDiver.common.ConstantMessages.DIVER_ADDED;
import static harpoonDiver.common.ExceptionMessages.DIVER_DOES_NOT_EXIST;

public class ControllerImpl implements Controller {
    private DiverRepository diverRepository;
    private DivingSiteRepository divingSiteRepository;
    private int siteCount;

    public ControllerImpl() {
        this.diverRepository = new DiverRepository();
        this.divingSiteRepository = new DivingSiteRepository();
        this.siteCount = 0;
    }

    @Override
    public String addDiver(String kind, String diverName) {
        //TODO
        Diver diver = null;
        if (kind.equals("OpenWaterDiver")) {
            diver = new OpenWaterDiver(diverName);
        } else if (kind.equals("DeepWaterDiver")) {
            diver = new DeepWaterDiver(diverName);
        } else if (kind.equals("WreckDiver")) {
            diver = new WreckDiver(diverName);
        } else {
            throw new IllegalArgumentException(String.format(DIVER_DOES_NOT_EXIST, diverName));
        }
        this.diverRepository.add(diver);
        return String.format(DIVER_ADDED, kind, diverName);
    }

    @Override
    public String addDivingSite(String siteName, String... seaCreatures) {
        //TODO

        DivingSite divingSite = new DivingSiteImpl(siteName);

      divingSite.getSeaCreatures().addAll(Arrays.asList(seaCreatures));


        this.divingSiteRepository.add(divingSite);
        return String.format(ConstantMessages.DIVING_SITE_ADDED, siteName);
    }

    @Override
    public String removeDiver(String diverName) {
      Diver diver = this.diverRepository.byName(diverName);

      if (diver==null){
          throw new IllegalArgumentException(String.format(DIVER_DOES_NOT_EXIST,diverName));
      }
      this.diverRepository.remove(diver);
        return String.format(ConstantMessages.DIVER_REMOVE,diverName);
    }

    @Override
    public String startDiving(String siteName) {
      siteCount++;
        DivingSite divingSite = this.divingSiteRepository.byName(siteName);
        Collection<Diver> divers = this.diverRepository.getCollection().stream()
                .filter(d -> d.getOxygen() > 30)
                .collect(Collectors.toList()); // Collect to List

        if (divers.isEmpty()) {
            throw new IllegalArgumentException("You must have at least one diver to start diving.");
        }

        Diving diving = new DivingImpl();
        diving.searching(divingSite, divers);
        int countDivers = (int)divers.stream().filter(d->!d.canDive()).count();
        return String.format("The dive took place at %s. %d diver/s was/were removed on this dive.", siteName, countDivers);
    }

    @Override
    public String getStatistics() {
        StringBuilder build = new StringBuilder();
        build.append(String.format(ConstantMessages.FINAL_DIVING_SITES, this.siteCount));
        build.append(System.lineSeparator());
        build.append(ConstantMessages.FINAL_DIVERS_STATISTICS);

        Collection<Diver> divers = diverRepository.getCollection();
        for (Diver diver : divers) {
            build.append(System.lineSeparator());
            build.append(String.format(ConstantMessages.FINAL_DIVER_NAME, diver.getName()));
            build.append(System.lineSeparator());
            build.append(String.format(ConstantMessages.FINAL_DIVER_OXYGEN, diver.getOxygen()));
            build.append(System.lineSeparator());
            if (diver.getSeaCatch().getSeaCreatures().isEmpty()) {
                build.append(String.format(ConstantMessages.FINAL_DIVER_CATCH, "None"));

            } else {
                build.append(String.format(ConstantMessages.FINAL_DIVER_CATCH,
                        String.join(ConstantMessages.FINAL_DIVER_CATCH_DELIMITER, diver.getSeaCatch().getSeaCreatures())));
            }
        }
        return build.toString();

    }
}
