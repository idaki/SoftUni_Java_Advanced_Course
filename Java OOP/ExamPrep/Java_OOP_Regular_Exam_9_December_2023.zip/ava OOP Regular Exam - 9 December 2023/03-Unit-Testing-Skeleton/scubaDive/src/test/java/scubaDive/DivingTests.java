package scubaDive;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class DivingTests {

    private DeepWaterDiver diver1;
    private DeepWaterDiver diver2;
    private Diving diving1;
    private Diving diving2;

    @Before
    public void setUp(){
        this.diver1 = new DeepWaterDiver("diver1",10);
        this.diver2 = new DeepWaterDiver("diver2",20);
        this.diving1 = new Diving("diving1",1);
        this.diving2 = new Diving("diving2",2);
    }

    @Test
    public void testConstructor(){
        Assert.assertEquals("diving1",this.diving1.getName());
        Assert.assertEquals(1,this.diving1.getCapacity());
    }

    @Test
    public void testGetCount(){
        this.diving1.addDeepWaterDiver(diver1);
        Assert.assertEquals(1,diving1.getCount());
    }

    @Test
    public void testGetName(){
        Assert.assertEquals("diving1",this.diving1.getName());
    }
    @Test
    public void testGetCapacity(){
        Assert.assertEquals(1,this.diving1.getCapacity());
    }

    @Test
    public void addDeepWaterDiverPositive(){
        this.diving2.addDeepWaterDiver(diver1);
        Assert.assertEquals(1,this.diving2.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void addDeepWaterDiverNoCapacity(){
        this.diving1.addDeepWaterDiver(diver1);
        this.diving1.addDeepWaterDiver(diver2);
    }
    @Test(expected = IllegalArgumentException.class)
    public void addDeepWaterDiverDiverExists(){
        this.diving2.addDeepWaterDiver(diver1);
        this.diving2.addDeepWaterDiver(diver1);
    }
    
    @Test
    public void removeDiverPositive(){
        this.diving2.addDeepWaterDiver(diver1);
        this.diving2.addDeepWaterDiver(diver2);
        this.diving2.removeDeepWaterDiver(diver1.getName());
        Assert.assertEquals(1,this.diving2.getCount());
    }
    
    @Test (expected =IllegalArgumentException.class )
    public void testSetCapacityWithNegativeValue(){
        Diving diving = new Diving("Negative", -3);
    }

    @Test (expected = NullPointerException.class)
    public void testSetNameWithEmptyName(){
        Diving diving = new Diving("", 5);
    }
    


}
