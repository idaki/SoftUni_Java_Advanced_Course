package catHouse.entities.houses;

import java.util.ArrayList;

public class LongHouse extends BaseHouse {
    public static final int CAPACITY = 30;

    public LongHouse(String name) {
        super(name, CAPACITY);

    }
}
