package vehicleShop.utils;

public final class IntegerUtils {
    private IntegerUtils() {
    }

    public static boolean isNegativeNumber(int input) {
        return input < 0;
    }

}
