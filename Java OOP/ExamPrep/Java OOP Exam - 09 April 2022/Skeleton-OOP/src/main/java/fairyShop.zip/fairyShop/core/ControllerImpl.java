package fairyShop.core;

import fairyShop.common.ConstantMessages;
import fairyShop.common.ExceptionMessages;
import fairyShop.models.*;
import fairyShop.repositories.HelperRepository;
import fairyShop.repositories.PresentRepository;
import fairyShop.utils.HelperUtils;

import java.util.ArrayList;
import java.util.List;

public class ControllerImpl implements Controller{
    private HelperRepository helperRepository;
    private PresentRepository presentRepository;
    private int countDonePresents;

    public ControllerImpl() {
        this.helperRepository = new HelperRepository();
        this.presentRepository = new PresentRepository();
        countDonePresents = 0;
    }

    @Override
    public String addHelper(String type, String helperName) {


        if (!HelperUtils.isHelperTypeValidToCreate(type)){
            throw new IllegalArgumentException(ExceptionMessages.HELPER_TYPE_DOESNT_EXIST);
        }
        Helper helper = HelperUtils.createNewHelper(type,helperName);

        helperRepository.add(helper);

        return String.format(ConstantMessages.ADDED_HELPER
                ,type
                ,helperName);
    }

    @Override
    public String addInstrumentToHelper(String helperName, int power) {
        Instrument instrument = new InstrumentImpl(power);
       Helper helper = helperRepository.findByName(helperName);
        if (!HelperUtils.helperIsExisting(helper)){
            throw new IllegalArgumentException(ExceptionMessages.HELPER_DOESNT_EXIST);
        }

        helper.addInstrument(instrument);

        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_INSTRUMENT_TO_HELPER
                ,power
                , helperName);
    }

    @Override
    public String addPresent(String presentName, int energyRequired) {
        Present present = new PresentImpl(presentName,energyRequired);
        presentRepository.add(present);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_PRESENT, presentName);
    }

    @Override
    public String craftPresent(String presentName) {
        Present present = presentRepository.findByName(presentName);
        Helper helper = helperRepository.getModels().stream()
                .filter(h->h.getEnergy()>50&& h.getInstruments().stream().anyMatch(i->!i.isBroken()))
                .findFirst()
                .orElse(null);

       if (!HelperUtils.isHelperReadyToStarWorking(helper)){
           Object ExceptionMessages = null;
           throw new IllegalArgumentException("There is no helper ready to start crafting!");
       }
        Shop shop = new ShopImpl();
        shop.craft(present, helper);
        if (present.isDone()){
            countDonePresents++;
        }
        String pattern = ConstantMessages.PRESENT_DONE
                +ConstantMessages.COUNT_BROKEN_INSTRUMENTS;

       long brokentInstruments =  helper.getInstruments().stream().filter(Instrument::isBroken).count();

        return String.format(pattern
                ,presentName
                ,present.isDone()
                        ? "done"
                        : "not done"
                ,brokentInstruments); //count to add

    }

    @Override
    public String report() {
      StringBuilder sb = new StringBuilder();

       String patternTitle = "%d presents are done!"
               +System.lineSeparator()
               + "Helpers info:"
               +System.lineSeparator();

       String title = String.format(patternTitle,countDonePresents);
      sb.append(title);



        for (Helper helper: helperRepository.getModels()) {
          String helperPrintInfo = HelperUtils.getHelperInfo(helper);
          sb.append(helperPrintInfo);
        }

        return sb.toString().trim();
    }
}
