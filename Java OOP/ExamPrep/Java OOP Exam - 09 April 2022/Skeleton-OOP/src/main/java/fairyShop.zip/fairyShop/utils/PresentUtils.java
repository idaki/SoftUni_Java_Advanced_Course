package fairyShop.utils;

public final class PresentUtils {
    private PresentUtils() {
    }
}
