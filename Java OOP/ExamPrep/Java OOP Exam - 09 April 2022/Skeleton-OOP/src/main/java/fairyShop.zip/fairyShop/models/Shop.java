package fairyShop.models;

public interface Shop {
    void craft(Present present, Helper helper);
}
