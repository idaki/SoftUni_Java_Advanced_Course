package fairyShop.utils;

import fairyShop.models.Helper;

public final class InstrumentsUtil {
    private InstrumentsUtil() {
    }
}