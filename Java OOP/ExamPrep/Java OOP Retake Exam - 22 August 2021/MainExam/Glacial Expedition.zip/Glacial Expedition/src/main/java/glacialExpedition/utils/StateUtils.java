package glacialExpedition.utils;

public final class StateUtils {

    private StateUtils() {
    }



}
