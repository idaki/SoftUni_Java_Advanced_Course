package glacialExpedition.utils;

public final class DoubleUtils {
    private DoubleUtils() {
    }

    public static boolean isNegative(double input) {
        return (input < 0);
    }
}
