package climbers.utils;

public final class DoubleUtils {

    private DoubleUtils() {
    }

    public static boolean isSmallerOrEqualToZero(double input) {
        return (input < 0);
    }


}
