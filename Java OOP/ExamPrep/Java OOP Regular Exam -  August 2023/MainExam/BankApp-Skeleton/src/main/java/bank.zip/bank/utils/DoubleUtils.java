package bank.utils;

public final class DoubleUtils {
    private DoubleUtils() {
    }

    public static boolean isNegativeOrZero (double input){
        return input<=0;
    }

}
