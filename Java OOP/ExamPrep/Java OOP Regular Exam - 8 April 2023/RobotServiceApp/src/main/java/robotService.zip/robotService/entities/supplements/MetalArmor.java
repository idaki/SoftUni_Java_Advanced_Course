package robotService.entities.supplements;

public class MetalArmor extends BaseSupplement{
    public static final int HARDNESS = 5;
    public static final double PRICE = 15;

    public MetalArmor() {
        super(HARDNESS, PRICE);
    }
}
